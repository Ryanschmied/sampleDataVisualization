module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "rootUser123",
    DB: "nanoleaf_coding_challenge",
    dialect: "mysql"
  };