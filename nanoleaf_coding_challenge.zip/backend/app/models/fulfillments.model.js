module.exports = (sequelize, Sequelize) => {
    const Fulfillments = sequelize.define("fulfillments", {
      salesOrderId: {
        type: Sequelize.STRING
      },
      num: {
        type: Sequelize.INTEGER
      },
      city: {
        type: Sequelize.STRING
      },
      country: {
        type: Sequelize.STRING
      },
      city: {
        type: Sequelize.STRING
      },
      provider: {
        type: Sequelize.STRING
      },
      trackingNumber: {
        type: Sequelize.STRING
      },
      deliveryDate: {
        type: Sequelize.DATE
      }
    });
    return Fulfillments;
  };