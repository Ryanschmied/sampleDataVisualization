To start the server, ensure your Node version supports ES6 features (I developed using v18.12.1). Then run 
```
npm i 
```
in the root of the 'backend' folder to install necessary dependencies.

Then run 

```
node server.js
```
To start the server, create the necessary tables and load the respective data into the databse.