import React, { useState, useEffect } from 'react';
import SalesDataService from '../services/sales.service';

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const OrdersPlaced = () => {
  const [salesData, setSalesData] = useState([]);
  useEffect(() => {
    getSalesData();
  }, []);

  const getSalesData = () => {
    SalesDataService.getAll()
     .then(res => {
      setSalesData(res.data);
     })
     .catch(e => {
      console.log(e)
     })
  }

  const chartData = {
    labels: salesData ? salesData.map(datum => datum.dateCreated.slice(0, 10)) : [],
    datasets: [
      {
        label: '# of Orders Placed',
        data: salesData ? salesData.map(() => 1) : [],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: '# Placed Orders over Time',
      },
    }
  };

  return (
    <div >
      {salesData ? (
        <Bar options={options} data={chartData}  />
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default OrdersPlaced;
