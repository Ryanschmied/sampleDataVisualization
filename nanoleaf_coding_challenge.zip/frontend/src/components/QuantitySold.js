import React, { useState, useEffect } from 'react';
import SalesDataService from '../services/sales.service';
import LineItemsDataService from '../services/lineItems.service';


import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const QuantitySold = () => {
  const [salesData, setSalesData] = useState([]);
  const [lineItemsData, setLineItemsData] = useState([]);

  useEffect(() => {
    getSalesData();
    getLineItemsData();

  }, []);

  const getSalesData = () => {
    SalesDataService.getAll()
     .then(res => {
      setSalesData(res.data);
     })
     .catch(e => {
      console.log(e)
     })
  }

  const getLineItemsData = () => {
    LineItemsDataService.getAll()
     .then(res => {
      setLineItemsData(res.data);
     })
     .catch(e => {
      console.log(e)
     })
  }

  const getQtySold = (salesOrderId) => {
    const orders = lineItemsData.filter(lineItem => lineItem.salesOrderId === salesOrderId);
    return orders.reduce((acc, order) => acc + order.qty, 0);
  }

  const chartData = {
    labels: salesData ? salesData.map(datum => datum.dateCreated.slice(0, 10)) : [],
    datasets: [
      {
        label: 'Qty Sold',
        data: salesData && lineItemsData ? salesData.map((data) => getQtySold(data.salesOrderId)) : [],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Items sold over time',
      },
    }
  };

  return (
    <div >
      {salesData ? (
        <Bar options={options} data={chartData}  />
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default QuantitySold;
