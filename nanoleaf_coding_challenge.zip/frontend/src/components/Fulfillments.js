import React, { useState, useEffect } from 'react';
import FulfillmentsDataService from '../services/fulfillments.service';

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const Fulfillments = () => {
  const [fulfillmentsData, setFulfillmentsData] = useState([]);
  useEffect(() => {
    getFulfillmentsData();
  }, []);

  const getFulfillmentsData = () => {
    FulfillmentsDataService.getAll()
     .then(res => {
      setFulfillmentsData(res.data);
     })
     .catch(e => {
      console.log(e)
     })
  }

  const chartData = {
    labels: fulfillmentsData ? fulfillmentsData.map(datum => datum.deliveryDate.slice(0, 10)) : [],
    datasets: [
      {
        label: '# of Fulfillments',
        data: fulfillmentsData ? fulfillmentsData.map(() => 1) : [],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: '# Fulfillments over Time',
      },
    }
  };

  return (
    <div >
      {fulfillmentsData ? (
        <Bar options={options} data={chartData}  />
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default Fulfillments;
