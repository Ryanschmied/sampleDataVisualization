import http from "../http-base";

const getAll = () => {
  return http.get("/lineItems");
};

const get = id => {
  return http.get(`/lineItems/${id}`);
};

const create = data => {
  return http.post("/lineItems", data);
};

const update = (id, data) => {
  return http.put(`/lineItems/${id}`, data);
};

const remove = id => {
  return http.delete(`/lineItems/${id}`);
};

const removeAll = () => {
  return http.delete(`/lineItems`);
};


const LineItemsDataService = {
  getAll,
  get,
  create,
  update,
  remove,
  removeAll
};

export default LineItemsDataService;