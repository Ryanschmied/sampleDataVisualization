import http from "../http-base";

const getAll = () => {
  return http.get("/fulfillments");
};

const get = id => {
  return http.get(`/fulfillments/${id}`);
};

const create = data => {
  return http.post("/fulfillments", data);
};

const update = (id, data) => {
  return http.put(`/fulfillments/${id}`, data);
};

const remove = id => {
  return http.delete(`/fulfillments/${id}`);
};

const removeAll = () => {
  return http.delete(`/fulfillments`);
};


const FulfillmentsDataService = {
  getAll,
  get,
  create,
  update,
  remove,
  removeAll
};

export default FulfillmentsDataService;