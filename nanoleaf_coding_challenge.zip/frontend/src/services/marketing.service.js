import http from "../http-base";

const getAll = () => {
  return http.get("/marketing");
};

const get = id => {
  return http.get(`/marketing/${id}`);
};

const create = data => {
  return http.post("/marketing", data);
};

const update = (id, data) => {
  return http.put(`/marketing/${id}`, data);
};

const remove = id => {
  return http.delete(`/marketing/${id}`);
};

const removeAll = () => {
  return http.delete(`/marketing`);
};


const MarketingDataService = {
  getAll,
  get,
  create,
  update,
  remove,
  removeAll
};

export default MarketingDataService;