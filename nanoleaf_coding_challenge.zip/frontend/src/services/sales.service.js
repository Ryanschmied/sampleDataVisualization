import http from "../http-base";

const getAll = () => {
  return http.get("/sales");
};

const get = id => {
  return http.get(`/sales/${id}`);
};

const create = data => {
  return http.post("/sales", data);
};

const update = (id, data) => {
  return http.put(`/sales/${id}`, data);
};

const remove = id => {
  return http.delete(`/sales/${id}`);
};

const removeAll = () => {
  return http.delete(`/sales`);
};


const SalesDataService = {
  getAll,
  get,
  create,
  update,
  remove,
  removeAll
};

export default SalesDataService;