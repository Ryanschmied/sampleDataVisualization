import React from "react";
import './App.less';
import "bootstrap/dist/css/bootstrap.min.css";
import WebVisitors from './components/WebVisitors';
import Fulfillments from "./components/Fulfillments";
import OrdersPlaced from "./components/OrdersPlaced";
import SalesRevenue from "./components/SalesRevenue";
import QuantitySold from "./components/QuantitySold";

function App() {
  return (
    <div className="App">
      <nav className="navbar navbar-expand navbar-dark bg-dark">
        <a href="" className="navbar-brand">
          Nanoleaf
        </a>
      </nav>
      <div>
        <WebVisitors />
        <Fulfillments />
        <OrdersPlaced />
        <SalesRevenue />
        <QuantitySold />
      </div>
    </div>
  );
}

export default App;
