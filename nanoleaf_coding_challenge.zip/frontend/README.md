To start the UI, ensure your Node version supports ES6 features (I developed using v18.12.1). Then run 
```
npm i 
```
in the root of the 'frontend' folder to install necessary dependencies.

Then run 

```
npm start
```
To start the dev server.

Ensure the backend server is running in a seperate terminal.
